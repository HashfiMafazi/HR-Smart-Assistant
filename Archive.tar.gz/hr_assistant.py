"""
HR Assistant
Entry point of the application.
"""
import os

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

from rich.console import Console
from rich.markdown import Markdown

from src.config import SIMILARITY_THRESHOLD
from src.document_loader import load_chunks
from src.vector_store import (
    build_vectorstore,
    get_context,
)
from src.memory import (
    load_memory,
    save_memory,
    add_memory,
    format_memory,
)
from src.prompt import PROMPT
from src.llm import generate
from src.utils import thinking

console = Console()


def initialize():
    """
    Initialize the application.
    """

    console.print("[bold green]🚀 Initializing HR Assistant...[/bold green]")

    chunks = load_chunks()

    build_vectorstore(chunks)

    console.print("[bold green]✅ Initialization complete.[/bold green]\n")


def chat():
    """
    Main chat loop.
    """

    history = load_memory()

    console.print(
        "[bold cyan]🧭 HR Assistant is ready![/bold cyan]\n"
        "Type 'exit' to quit.\n"
    )

    while True:

        question = console.input("[bold blue]You:[/bold blue] ")

        if question.lower() in ("exit", "quit"):
            console.print("[bold yellow]👋 Goodbye![/bold yellow]")
            break

        thinking()

        # Retrieve context and document sources
        context, sources = get_context(question)

        # Safety check
        if not sources:
            console.print(
                "[bold yellow]⚠ No relevant HR policy was found.[/bold yellow]\n"
            )
            continue

        # Lowest score = Best match
        best_score = min(source["score"] for source in sources)

        console.print(f"[yellow]Similarity score: {best_score:.4f}[/yellow]")

        if best_score > SIMILARITY_THRESHOLD:
            console.print(
                "[bold yellow]⚠ I couldn't find relevant information in the HR policy.[/bold yellow]\n"
            )
            continue

        memory = format_memory(history)

        full_prompt = PROMPT.format(
            context=context,
            memory=memory,
            question=question,
        )

        answer = generate(full_prompt)

        history = add_memory(
            history,
            question,
            answer,
        )

        save_memory(history)

        console.print()

        console.print("[bold magenta]HR Assistant[/bold magenta]")

        console.print(Markdown(answer))

        # Display document sources
        console.print("\n[bold cyan]📄 Sources[/bold cyan]")

        shown = set()

        for source in sources:

            key = (source["source"], source["page"])

            if key in shown:
                continue

            shown.add(key)

            console.print(
                f"• {source['source']} (Page {source['page'] + 1})"
            )

        console.print()


def main():
    initialize()
    chat()


if __name__ == "__main__":
    main()
