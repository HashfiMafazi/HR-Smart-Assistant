"""
FAISS Vector Store

Responsibilities:
- Build the vector database
- Load the vector database
- Retrieve relevant context
"""

import os

from langchain_community.vectorstores import FAISS
from langchain_huggingface.embeddings import HuggingFaceEmbeddings

from src.config import VECTORSTORE_PATH


# ----------------------------------------------------
# Global variables (lazy loading)
# ----------------------------------------------------

_embedding = None
_vectordb = None


# ----------------------------------------------------
# Embedding Model
# ----------------------------------------------------

def get_embedding():
    global _embedding

    if _embedding is None:
        print("🧠 Loading embedding model (offline mode)...")

        _embedding = HuggingFaceEmbeddings(
            model_name="sentence-transformers/all-MiniLM-L6-v2",
            model_kwargs={
                "local_files_only": True,
            },
        )

    return _embedding


# ----------------------------------------------------
# Build Vector Store
# ----------------------------------------------------

def build_vectorstore(chunks):
    """
    Build the FAISS index only if it does not exist.
    """

    if os.path.exists(os.path.join(VECTORSTORE_PATH, "index.faiss")):

        print("✅ Existing FAISS index found.")

        return

    print("⚙️ Building FAISS index...")

    embedding = get_embedding()

    vectordb = FAISS.from_documents(
        chunks,
        embedding,
    )

    os.makedirs(VECTORSTORE_PATH, exist_ok=True)

    vectordb.save_local(VECTORSTORE_PATH)

    print("💾 FAISS index saved.")


# ----------------------------------------------------
# Load Vector Store
# ----------------------------------------------------

def get_vectorstore():
    """
    Lazy load FAISS only once.
    """

    global _vectordb

    if _vectordb is not None:
        return _vectordb

    print("📂 Loading FAISS index...")

    _vectordb = FAISS.load_local(
        VECTORSTORE_PATH,
        get_embedding(),
        allow_dangerous_deserialization=True,
    )

    return _vectordb


# ----------------------------------------------------
# Context Retrieval
# ----------------------------------------------------

def get_context(question, k=2):
    """
    Retrieve the most relevant context.

    Returns:
        context (str)
        sources (list)
    """

    vectordb = get_vectorstore()

    docs_with_scores = vectordb.similarity_search_with_score(
        question,
        k=k,
    )

    contexts = []
    sources = []

    # Lower score = better match
    MAX_SCORE = 0.8

    for doc, score in docs_with_scores:

        if score > MAX_SCORE:
            continue

        contexts.append(doc.page_content)

        metadata = doc.metadata

        sources.append({
            "page": metadata.get("page", 0),
            "source": os.path.basename(
                metadata.get("source", "Unknown")
            ),
            "score": float(score),
        })

    print("\nRetrieved chunks:")
    for source in sources:
        print(
            f"{source['source']} | "
            f"Page {source['page'] + 1} | "
            f"Score: {source['score']:.4f}"
        )

    return "\n\n".join(contexts), sources
